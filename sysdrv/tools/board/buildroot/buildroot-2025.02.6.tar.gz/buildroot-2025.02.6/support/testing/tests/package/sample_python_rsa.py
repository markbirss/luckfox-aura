import rsa
(pubkey, privkey) = rsa.newkeys(512)
