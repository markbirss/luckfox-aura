#include <stdlib.h>
#include <stdio.h>

int
main(void)
{
    printf("Hello Buildroot!\n");
    exit(EXIT_SUCCESS);
}
