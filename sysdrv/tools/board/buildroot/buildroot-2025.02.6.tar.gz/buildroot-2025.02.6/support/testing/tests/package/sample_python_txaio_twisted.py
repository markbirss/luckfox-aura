import txaio
txaio.use_twisted()
f0 = txaio.create_future()
