#! /usr/bin/env python3

print("Hello Buildroot!")
