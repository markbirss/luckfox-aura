import hid

hid.enumerate()
