import distro

assert(distro.name() == 'Buildroot')
assert(distro.id() == 'buildroot')
