from tests.package.test_python import TestPythonPackageBase


class TestPythonPy3Pysmb(TestPythonPackageBase):
    __test__ = True
    config = TestPythonPackageBase.config + \
        """
        BR2_PACKAGE_PYTHON3=y
        BR2_PACKAGE_PYTHON_PYSMB=y
        """
    sample_scripts = ["tests/package/sample_python_pysmb.py"]
    timeout = 40
