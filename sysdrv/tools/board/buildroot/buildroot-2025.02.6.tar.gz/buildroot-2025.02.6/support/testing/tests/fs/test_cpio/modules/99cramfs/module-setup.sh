check() {
    return 0
}

depends() {
    return 0
}

install() {
    inst_multiple /usr/bin/cramfsck
}
