import nacl.utils

nonce = nacl.utils.random(16)
