#! /bin/sh

echo "Hello Buildroot!"
