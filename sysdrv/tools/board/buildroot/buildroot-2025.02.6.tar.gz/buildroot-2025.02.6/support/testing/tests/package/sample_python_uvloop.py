import uvloop

async def main():
    print("Hello world!")

uvloop.run(main())
